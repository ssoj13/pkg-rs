# -*- coding: utf-8 -*-

name = 'depressive'

version = '1.7.51'

requires = [
    'fig-1',
    'special-0',
    'robot-0',
    'fool-2014+<2017',
    'cart-0',
    'lecture-2.19+<3'
]

timestamp = 1600130227

format_version = 2
