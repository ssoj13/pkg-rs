# -*- coding: utf-8 -*-

name = 'depressive'

version = '1.1.84'

requires = [
    'fig-1',
    'special-0',
    'fool-2014+<2017',
    'cart-0'
]

timestamp = 1600130318

format_version = 2
