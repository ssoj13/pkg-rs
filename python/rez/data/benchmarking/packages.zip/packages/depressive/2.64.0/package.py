# -*- coding: utf-8 -*-

name = 'depressive'

version = '2.64.0'

requires = [
    'impala-0',
    'disconnection-2',
    'fool-2014+<2019',
    'weapon-2.49+<3',
    'service-1',
    'harmony-1',
    'fig-1',
    'authorization-3',
    'detective-0',
    'profit-4',
    'elephant-1',
    'periodical-1',
    'special-0',
    'robot-0',
    'armoire-3+<5'
]

timestamp = 1600130396

format_version = 2
