# -*- coding: utf-8 -*-

name = 'depressive'

version = '1.10.62'

requires = [
    'fig-1',
    'special-0',
    'robot-0',
    'fool-2014+<2017',
    'cart-0',
    'lecture-2.19+<3'
]

timestamp = 1600130303

format_version = 2
