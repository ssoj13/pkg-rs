# -*- coding: utf-8 -*-

name = 'depressive'

version = '1.2.46'

requires = [
    'fig-1',
    'special-0',
    'fool-2014+<2017',
    'cart-0'
]

timestamp = 1600130772

format_version = 2
