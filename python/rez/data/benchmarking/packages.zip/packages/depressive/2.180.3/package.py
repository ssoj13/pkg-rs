# -*- coding: utf-8 -*-

name = 'depressive'

version = '2.180.3'

requires = [
    'impala-0',
    'otter-1.27+<2',
    'disconnection-2.280+<3',
    'fool-2014+<2020',
    'weapon-2.49+<3',
    'paper-0+<1',
    'student-0.4+<1',
    'peacoat-9',
    'service-1',
    'harmony-1+<3',
    'fig-1',
    'authorization-3',
    'detective-0',
    'profit-4',
    'elephant-1',
    'periodical-1',
    'special-0+<2',
    'robot-0',
    'armoire-3+<5'
]

timestamp = 1600130117

format_version = 2
