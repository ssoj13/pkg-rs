# -*- coding: utf-8 -*-

name = 'depressive'

version = '1.0.55'

requires = [
    'fool-2014+<2016',
    'cart-0'
]

timestamp = 1600130667

format_version = 2
