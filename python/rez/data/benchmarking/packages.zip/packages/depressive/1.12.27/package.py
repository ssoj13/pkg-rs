# -*- coding: utf-8 -*-

name = 'depressive'

version = '1.12.27'

requires = [
    'fool-2014+<2017',
    'cart-0',
    'lecture-2.19+<3',
    'ram-4',
    'pecan-1',
    'scrambled-0.4+<1',
    'fig-1',
    'special-0',
    'robot-0',
    'elephant-1'
]

timestamp = 1600130755

format_version = 2
